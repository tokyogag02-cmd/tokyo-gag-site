TOKYO GAG Video Site Fixed

修正内容:
- BAR Instagramリンク: https://www.instagram.com/bar_doncondaane/
- キッチンカー画像を最新の榮登庵画像に差し替え
- TOP動画の最後の不要な文字部分をカット

公開方法:
ZIPを解凍し、中身をそのままサーバー公開フォルダへアップロードしてください。
