TOKYO GAG GitHub Ready Site

このZIPはGitHubアップロード用です。
フォルダ構成をなくし、すべて同じ階層で動くようにしています。

アップロードするファイル:
- index.html
- style.css
- app.js
- hero.jpg
- kitchen.jpg
- bar_logo.jpg
- tokyo_gag_logo.png
- hero.mp4
- README.txt

注意:
ZIPのままではなく、解凍して中身を全部GitHubへアップロードしてください。
既に間違えてアップロードしたZIPや素材ファイルがある場合は削除してから、この中身をアップロードしてください。

BAR Instagram:
https://www.instagram.com/bar_doncondaane/
